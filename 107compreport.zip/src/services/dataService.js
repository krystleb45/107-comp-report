
var catalog = [
    {
    _id: "1234343hhfhahudsf76",
        title: "laptop",
        image: "Laptop-computer.jpg",
        price: 1200.00,
        category: "laptops",
        stock: 10,
        minimum: 1,
    },
    {
        _id: "ththeuahtiuahet7494",
        title: "Desktop",
        image: "desktop.jpeg",
        price: 600.00,
        category: "desktop",
        stock: 10,
        minimum: 1,
    },
    {
        _id: "ththeuahtiuahet7494",
        title: "Modem",
        image: "modem.jpeg",
        price: 100.00,
        category: "modem",
        stock: 10,
        minimum: 1,
    },
    {
        _id: "ththeuahtiuahet7494",
        title: "printer",
        image: "printer.jpg",
        price: 500.00,
        category: "printer",
        stock: 10,
        minimum: 1,
    },
    {
        _id: "ththeuahtiuahet7494",
        title: "Cell Phone",
        image: "cell phone.jpeg",
        price: 1000.00,
        category: "phone",
        stock: 10,
        minimum: 1,
    },
    {
        _id: "ththeuahtiuahet7494",
        title: "Phone Charger",
        image: "phone charger.jpeg",
        price: 25.00,
        category: "accessories",
        stock: 10,
        minimum: 1,
    },

];

class DataService{

    getCatalog(){
        //call the server to get catalog

        //return mock data (temporal)
        return catalog;
    }
    saveItem(){

    }
    saveOrder(){

    }
}
export default DataService;